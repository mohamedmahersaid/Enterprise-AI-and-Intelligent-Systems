"""REST Gateway Store Mixin - Gateway API implementation for REST-based tracking stores."""

from __future__ import annotations

from typing import Any

from mlflow.entities import (
    GatewayEndpoint,
    GatewayEndpointBinding,
    GatewayEndpointModelConfig,
    GatewayEndpointModelMapping,
    GatewayEndpointTag,
    GatewayModelDefinition,
    GatewayResourceType,
    GatewaySecretInfo,
    RoutingStrategy,
)
from mlflow.entities.gateway_budget_policy import (
    BudgetAction,
    BudgetDuration,
    BudgetTargetScope,
    BudgetUnit,
    GatewayBudgetPolicy,
)
from mlflow.entities.gateway_guardrail import (
    GatewayGuardrail,
    GatewayGuardrailConfig,
    GuardrailAction,
    GuardrailStage,
)
from mlflow.protos.service_pb2 import (
    AddGuardrailToEndpoint,
    AttachModelToGatewayEndpoint,
    CreateGatewayBudgetPolicy,
    CreateGatewayEndpoint,
    CreateGatewayEndpointBinding,
    CreateGatewayGuardrail,
    CreateGatewayModelDefinition,
    CreateGatewaySecret,
    DeleteGatewayBudgetPolicy,
    DeleteGatewayEndpoint,
    DeleteGatewayEndpointBinding,
    DeleteGatewayEndpointTag,
    DeleteGatewayGuardrail,
    DeleteGatewayModelDefinition,
    DeleteGatewaySecret,
    DetachModelFromGatewayEndpoint,
    FallbackConfig,
    GetGatewayBudgetPolicy,
    GetGatewayEndpoint,
    GetGatewayGuardrail,
    GetGatewayModelDefinition,
    GetGatewaySecretInfo,
    ListEndpointGuardrailConfigs,
    ListGatewayBudgetPolicies,
    ListGatewayEndpointBindings,
    ListGatewayEndpoints,
    ListGatewayGuardrails,
    ListGatewayModelDefinitions,
    ListGatewaySecretInfos,
    RemoveGuardrailFromEndpoint,
    SetGatewayEndpointTag,
    UpdateEndpointGuardrailConfig,
    UpdateGatewayBudgetPolicy,
    UpdateGatewayEndpoint,
    UpdateGatewayModelDefinition,
    UpdateGatewaySecret,
)
from mlflow.store.entities.paged_list import PagedList
from mlflow.store.tracking import SEARCH_MAX_RESULTS_DEFAULT
from mlflow.utils.proto_json_utils import message_to_json


class RestGatewayStoreMixin:
    """Mixin class providing Gateway API implementation for REST-based tracking stores.

    This mixin adds Gateway functionality to REST tracking stores, enabling
    management of secrets, model definitions, endpoints, and bindings
    for the MLflow AI Gateway via REST API calls.

    The mixin expects the implementing class to provide:
    - _call_endpoint(api, json_body): Method to make REST API calls
    """

    # Set of v3 Gateway APIs (secrets, endpoints, model definitions, bindings)
    _V3_GATEWAY_APIS = {
        CreateGatewaySecret,
        GetGatewaySecretInfo,
        UpdateGatewaySecret,
        DeleteGatewaySecret,
        ListGatewaySecretInfos,
        CreateGatewayEndpoint,
        GetGatewayEndpoint,
        UpdateGatewayEndpoint,
        DeleteGatewayEndpoint,
        ListGatewayEndpoints,
        CreateGatewayModelDefinition,
        GetGatewayModelDefinition,
        ListGatewayModelDefinitions,
        UpdateGatewayModelDefinition,
        DeleteGatewayModelDefinition,
        AttachModelToGatewayEndpoint,
        DetachModelFromGatewayEndpoint,
        CreateGatewayEndpointBinding,
        DeleteGatewayEndpointBinding,
        ListGatewayEndpointBindings,
        SetGatewayEndpointTag,
        DeleteGatewayEndpointTag,
        CreateGatewayBudgetPolicy,
        GetGatewayBudgetPolicy,
        UpdateGatewayBudgetPolicy,
        DeleteGatewayBudgetPolicy,
        ListGatewayBudgetPolicies,
        CreateGatewayGuardrail,
        GetGatewayGuardrail,
        DeleteGatewayGuardrail,
        ListGatewayGuardrails,
        AddGuardrailToEndpoint,
        RemoveGuardrailFromEndpoint,
        ListEndpointGuardrailConfigs,
        UpdateEndpointGuardrailConfig,
    }

    # ========== Secrets Management APIs ==========

    def create_gateway_secret(
        self,
        secret_name: str,
        secret_value: dict[str, str],
        provider: str | None = None,
        auth_config: dict[str, Any] | None = None,
        created_by: str | None = None,
    ) -> GatewaySecretInfo:
        """
        Create a new secret for secure credential storage.

        Args:
            secret_name: Name to identify the secret.
            secret_value: The secret value(s) to encrypt and store as key-value pairs.
                For simple API keys: {"api_key": "sk-xxx"}
                For compound credentials: {"aws_access_key_id": "...",
                  "aws_secret_access_key": "..."}
            provider: Optional provider name (e.g., "openai", "anthropic").
            auth_config: Optional dict with authentication configuration. For providers
                with multiple auth modes, include "auth_mode" key (e.g.,
                {"auth_mode": "access_keys", "aws_region_name": "us-east-1"}).
            created_by: Optional identifier of the user creating the secret.

        Returns:
            The created GatewaySecretInfo object with masked value.
        """
        req_body = message_to_json(
            CreateGatewaySecret(
                secret_name=secret_name,
                secret_value=secret_value,
                provider=provider,
                auth_config=auth_config or {},
                created_by=created_by,
            )
        )
        response_proto = self._call_endpoint(CreateGatewaySecret, req_body)
        return GatewaySecretInfo.from_proto(response_proto.secret)

    def get_secret_info(
        self, secret_id: str | None = None, secret_name: str | None = None
    ) -> GatewaySecretInfo:
        """
        Retrieve information about a secret (value will be masked).

        Args:
            secret_id: The unique identifier of the secret.
            secret_name: The name of the secret.

        Returns:
            The GatewaySecretInfo object with masked value.
        """
        req_body = message_to_json(
            GetGatewaySecretInfo(secret_id=secret_id, secret_name=secret_name)
        )
        response_proto = self._call_endpoint(GetGatewaySecretInfo, req_body)
        return GatewaySecretInfo.from_proto(response_proto.secret)

    def update_gateway_secret(
        self,
        secret_id: str,
        secret_value: dict[str, str] | None = None,
        auth_config: dict[str, Any] | None = None,
        updated_by: str | None = None,
    ) -> GatewaySecretInfo:
        """
        Update an existing secret's configuration.

        Args:
            secret_id: The unique identifier of the secret to update.
            secret_value: Optional new secret value(s) for key rotation as key-value pairs,
                or None to leave unchanged.
                For simple API keys: {"api_key": "sk-xxx"}
                For compound credentials: {"aws_access_key_id": "...",
                  "aws_secret_access_key": "..."}
            auth_config: Optional dict with authentication configuration.
            updated_by: Optional identifier of the user updating the secret.

        Returns:
            The updated GatewaySecretInfo object with masked value.
        """
        req_body = message_to_json(
            UpdateGatewaySecret(
                secret_id=secret_id,
                secret_value=secret_value or {},
                auth_config=auth_config or {},
                updated_by=updated_by,
            )
        )
        response_proto = self._call_endpoint(UpdateGatewaySecret, req_body)
        return GatewaySecretInfo.from_proto(response_proto.secret)

    def delete_gateway_secret(self, secret_id: str) -> None:
        """
        Delete a secret.

        Args:
            secret_id: The unique identifier of the secret to delete.
        """
        req_body = message_to_json(DeleteGatewaySecret(secret_id=secret_id))
        self._call_endpoint(DeleteGatewaySecret, req_body)

    def list_secret_infos(self, provider: str | None = None) -> list[GatewaySecretInfo]:
        """
        List all secret metadata, optionally filtered by provider.

        Args:
            provider: Optional provider name to filter secrets.

        Returns:
            List of GatewaySecretInfo objects with masked values.
        """
        req_body = message_to_json(ListGatewaySecretInfos(provider=provider))
        response_proto = self._call_endpoint(ListGatewaySecretInfos, req_body)
        return [GatewaySecretInfo.from_proto(s) for s in response_proto.secrets]

    # ========== Endpoints Management APIs ==========

    def create_gateway_endpoint(
        self,
        name: str,
        model_configs: list[GatewayEndpointModelConfig],
        created_by: str | None = None,
        routing_strategy: RoutingStrategy | None = None,
        fallback_config: FallbackConfig | None = None,
        experiment_id: str | None = None,
        usage_tracking: bool = True,
    ) -> GatewayEndpoint:
        """
        Create a new endpoint with associated model definitions.

        Args:
            name: Name to identify the endpoint.
            model_configs: List of model configurations specifying model_definition_id,
                          linkage_type, weight, and fallback_order for each model.
            created_by: Optional identifier of the user creating the endpoint.
            routing_strategy: Optional routing strategy for the endpoint.
            fallback_config: Optional fallback configuration (includes strategy and max_attempts).
            experiment_id: Optional experiment ID for tracing. Only used when usage_tracking
                          is True. If not provided and usage_tracking is True, one is auto-created.
            usage_tracking: Whether to enable usage tracking for this endpoint.

        Returns:
            The created GatewayEndpoint object with associated model mappings.
        """
        req_body = message_to_json(
            CreateGatewayEndpoint(
                name=name,
                model_configs=[config.to_proto() for config in model_configs],
                created_by=created_by,
                routing_strategy=routing_strategy.to_proto() if routing_strategy else None,
                fallback_config=fallback_config.to_proto() if fallback_config else None,
                experiment_id=experiment_id,
                usage_tracking=usage_tracking,
            )
        )
        response_proto = self._call_endpoint(CreateGatewayEndpoint, req_body)
        return GatewayEndpoint.from_proto(response_proto.endpoint)

    def get_gateway_endpoint(
        self, endpoint_id: str | None = None, name: str | None = None
    ) -> GatewayEndpoint:
        """
        Retrieve an endpoint with its model configurations.

        Args:
            endpoint_id: The unique identifier of the endpoint.
            name: The name of the endpoint.

        Returns:
            The GatewayEndpoint object with associated models.
        """
        req_body = message_to_json(GetGatewayEndpoint(endpoint_id=endpoint_id, name=name))
        response_proto = self._call_endpoint(GetGatewayEndpoint, req_body)
        return GatewayEndpoint.from_proto(response_proto.endpoint)

    def update_gateway_endpoint(
        self,
        endpoint_id: str,
        name: str | None = None,
        updated_by: str | None = None,
        routing_strategy: RoutingStrategy | None = None,
        fallback_config: FallbackConfig | None = None,
        model_configs: list[GatewayEndpointModelConfig] | None = None,
        experiment_id: str | None = None,
        usage_tracking: bool | None = None,
    ) -> GatewayEndpoint:
        """
        Update an endpoint's configuration.

        Args:
            endpoint_id: The unique identifier of the endpoint to update.
            name: Optional new name for the endpoint.
            updated_by: Optional identifier of the user updating the endpoint.
            routing_strategy: Optional new routing strategy for the endpoint.
            fallback_config: Optional fallback configuration (includes strategy and max_attempts).
            model_configs: Optional new list of model configurations (replaces all linkages).
            experiment_id: Optional new experiment ID for tracing.
            usage_tracking: Optional flag to enable/disable usage tracking.

        Returns:
            The updated GatewayEndpoint object.
        """
        req_body = message_to_json(
            UpdateGatewayEndpoint(
                endpoint_id=endpoint_id,
                name=name,
                updated_by=updated_by,
                routing_strategy=routing_strategy.to_proto() if routing_strategy else None,
                fallback_config=fallback_config.to_proto() if fallback_config else None,
                model_configs=[config.to_proto() for config in model_configs]
                if model_configs
                else [],
                experiment_id=experiment_id,
                usage_tracking=usage_tracking,
            )
        )
        response_proto = self._call_endpoint(UpdateGatewayEndpoint, req_body)
        return GatewayEndpoint.from_proto(response_proto.endpoint)

    def delete_gateway_endpoint(self, endpoint_id: str) -> None:
        """
        Delete an endpoint and all its associated models and bindings.

        Args:
            endpoint_id: The unique identifier of the endpoint to delete.
        """
        req_body = message_to_json(DeleteGatewayEndpoint(endpoint_id=endpoint_id))
        self._call_endpoint(DeleteGatewayEndpoint, req_body)

    def list_gateway_endpoints(self, provider: str | None = None) -> list[GatewayEndpoint]:
        """
        List all endpoints, optionally filtered by provider.

        Args:
            provider: Optional provider name to filter endpoints.

        Returns:
            List of GatewayEndpoint objects with their associated models.
        """
        req_body = message_to_json(ListGatewayEndpoints(provider=provider))
        response_proto = self._call_endpoint(ListGatewayEndpoints, req_body)
        return [GatewayEndpoint.from_proto(e) for e in response_proto.endpoints]

    # ========== Model Definitions Management APIs ==========

    def create_gateway_model_definition(
        self,
        name: str,
        secret_id: str,
        provider: str,
        model_name: str,
        created_by: str | None = None,
    ) -> GatewayModelDefinition:
        """
        Create a reusable model definition.

        Args:
            name: User-friendly name for the model definition.
            secret_id: ID of the secret containing API credentials.
            provider: Provider name (e.g., "openai", "anthropic").
            model_name: Name of the model (e.g., "gpt-4", "claude-3-5-sonnet").
            created_by: Optional identifier of the user creating the definition.

        Returns:
            The created GatewayModelDefinition object.
        """
        req_body = message_to_json(
            CreateGatewayModelDefinition(
                name=name,
                secret_id=secret_id,
                provider=provider,
                model_name=model_name,
                created_by=created_by,
            )
        )
        response_proto = self._call_endpoint(CreateGatewayModelDefinition, req_body)
        return GatewayModelDefinition.from_proto(response_proto.model_definition)

    def get_gateway_model_definition(self, model_definition_id: str) -> GatewayModelDefinition:
        """
        Retrieve a model definition by ID.

        Args:
            model_definition_id: The unique identifier of the model definition.

        Returns:
            The GatewayModelDefinition object.
        """
        req_body = message_to_json(
            GetGatewayModelDefinition(model_definition_id=model_definition_id)
        )
        response_proto = self._call_endpoint(GetGatewayModelDefinition, req_body)
        return GatewayModelDefinition.from_proto(response_proto.model_definition)

    def list_gateway_model_definitions(
        self,
        provider: str | None = None,
        secret_id: str | None = None,
    ) -> list[GatewayModelDefinition]:
        """
        List all model definitions, optionally filtered.

        Args:
            provider: Optional provider name to filter definitions.
            secret_id: Optional secret ID to filter definitions.

        Returns:
            List of GatewayModelDefinition objects.
        """
        req_body = message_to_json(
            ListGatewayModelDefinitions(provider=provider, secret_id=secret_id)
        )
        response_proto = self._call_endpoint(ListGatewayModelDefinitions, req_body)
        return [GatewayModelDefinition.from_proto(m) for m in response_proto.model_definitions]

    def update_gateway_model_definition(
        self,
        model_definition_id: str,
        name: str | None = None,
        secret_id: str | None = None,
        model_name: str | None = None,
        updated_by: str | None = None,
        provider: str | None = None,
    ) -> GatewayModelDefinition:
        """
        Update a model definition.

        Args:
            model_definition_id: The unique identifier of the model definition.
            name: Optional new name.
            secret_id: Optional new secret ID.
            model_name: Optional new model name.
            updated_by: Optional identifier of the user updating the definition.
            provider: Optional new provider.

        Returns:
            The updated GatewayModelDefinition object.
        """
        req_body = message_to_json(
            UpdateGatewayModelDefinition(
                model_definition_id=model_definition_id,
                name=name,
                secret_id=secret_id,
                model_name=model_name,
                updated_by=updated_by,
                provider=provider,
            )
        )
        response_proto = self._call_endpoint(UpdateGatewayModelDefinition, req_body)
        return GatewayModelDefinition.from_proto(response_proto.model_definition)

    def delete_gateway_model_definition(self, model_definition_id: str) -> None:
        """
        Delete a model definition (fails if in use by any endpoint).

        Args:
            model_definition_id: The unique identifier of the model definition.
        """
        req_body = message_to_json(
            DeleteGatewayModelDefinition(model_definition_id=model_definition_id)
        )
        self._call_endpoint(DeleteGatewayModelDefinition, req_body)

    # ========== Endpoint Model Mappings Management APIs ==========

    def attach_model_to_endpoint(
        self,
        endpoint_id: str,
        model_config: GatewayEndpointModelConfig,
        created_by: str | None = None,
    ) -> GatewayEndpointModelMapping:
        """
        Attach a model definition to an endpoint.

        Args:
            endpoint_id: The unique identifier of the endpoint.
            model_config: Configuration for the model to attach.
            created_by: Optional identifier of the user creating the mapping.

        Returns:
            The created GatewayEndpointModelMapping object.
        """
        req_body = message_to_json(
            AttachModelToGatewayEndpoint(
                endpoint_id=endpoint_id,
                model_config=model_config.to_proto(),
                created_by=created_by,
            )
        )
        response_proto = self._call_endpoint(AttachModelToGatewayEndpoint, req_body)
        return GatewayEndpointModelMapping.from_proto(response_proto.mapping)

    def detach_model_from_endpoint(
        self,
        endpoint_id: str,
        model_definition_id: str,
    ) -> None:
        """
        Detach a model definition from an endpoint.

        Args:
            endpoint_id: The unique identifier of the endpoint.
            model_definition_id: The unique identifier of the model definition.
        """
        req_body = message_to_json(
            DetachModelFromGatewayEndpoint(
                endpoint_id=endpoint_id,
                model_definition_id=model_definition_id,
            )
        )
        self._call_endpoint(DetachModelFromGatewayEndpoint, req_body)

    # ========== Endpoint Bindings Management APIs ==========

    def create_endpoint_binding(
        self,
        endpoint_id: str,
        resource_type: GatewayResourceType,
        resource_id: str,
        created_by: str | None = None,
    ) -> GatewayEndpointBinding:
        """
        Create a binding between an endpoint and a resource.

        Args:
            endpoint_id: The unique identifier of the endpoint.
            resource_type: Type of resource to bind.
            resource_id: The unique identifier of the resource.
            created_by: Optional identifier of the user creating the binding.

        Returns:
            The created GatewayEndpointBinding object.
        """
        req_body = message_to_json(
            CreateGatewayEndpointBinding(
                endpoint_id=endpoint_id,
                resource_type=resource_type.value,
                resource_id=resource_id,
                created_by=created_by,
            )
        )
        response_proto = self._call_endpoint(CreateGatewayEndpointBinding, req_body)
        return GatewayEndpointBinding.from_proto(response_proto.binding)

    def delete_endpoint_binding(
        self, endpoint_id: str, resource_type: str, resource_id: str
    ) -> None:
        """
        Delete a binding between an endpoint and a resource.

        Args:
            endpoint_id: ID of the endpoint.
            resource_type: Type of resource bound to the endpoint.
            resource_id: ID of the resource.
        """
        req_body = message_to_json(
            DeleteGatewayEndpointBinding(
                endpoint_id=endpoint_id,
                resource_type=resource_type,
                resource_id=resource_id,
            )
        )
        self._call_endpoint(DeleteGatewayEndpointBinding, req_body)

    def list_endpoint_bindings(
        self,
        endpoint_id: str | None = None,
        resource_type: GatewayResourceType | None = None,
        resource_id: str | None = None,
    ) -> list[GatewayEndpointBinding]:
        """
        List endpoint bindings with optional server-side filtering.

        Args:
            endpoint_id: Optional endpoint ID to filter bindings.
            resource_type: Optional resource type to filter bindings.
            resource_id: Optional resource ID to filter bindings.

        Returns:
            List of GatewayEndpointBinding objects matching the filters.
        """
        req_body = message_to_json(
            ListGatewayEndpointBindings(
                endpoint_id=endpoint_id,
                resource_type=resource_type.value if resource_type else None,
                resource_id=resource_id,
            )
        )
        response_proto = self._call_endpoint(ListGatewayEndpointBindings, req_body)
        return [GatewayEndpointBinding.from_proto(b) for b in response_proto.bindings]

    def set_gateway_endpoint_tag(self, endpoint_id: str, tag: GatewayEndpointTag) -> None:
        """
        Set a tag on an endpoint.

        Args:
            endpoint_id: ID of the endpoint to tag.
            tag: GatewayEndpointTag with key and value to set.
        """
        req_body = message_to_json(
            SetGatewayEndpointTag(
                endpoint_id=endpoint_id,
                key=tag.key,
                value=tag.value,
            )
        )
        self._call_endpoint(SetGatewayEndpointTag, req_body)

    def delete_gateway_endpoint_tag(self, endpoint_id: str, key: str) -> None:
        """
        Delete a tag from an endpoint.

        Args:
            endpoint_id: ID of the endpoint.
            key: Tag key to delete.
        """
        req_body = message_to_json(
            DeleteGatewayEndpointTag(
                endpoint_id=endpoint_id,
                key=key,
            )
        )
        self._call_endpoint(DeleteGatewayEndpointTag, req_body)

    # ========== Budget Policy Management APIs ==========

    def create_budget_policy(
        self,
        budget_unit: BudgetUnit,
        budget_amount: float,
        duration: BudgetDuration,
        target_scope: BudgetTargetScope,
        budget_action: BudgetAction,
        created_by: str | None = None,
        target_value: str | None = None,
    ) -> GatewayBudgetPolicy:
        req_body = message_to_json(
            CreateGatewayBudgetPolicy(
                budget_unit=budget_unit.to_proto(),
                budget_amount=budget_amount,
                duration=duration.to_proto(),
                target_scope=target_scope.to_proto(),
                budget_action=budget_action.to_proto(),
                created_by=created_by,
                target_value=target_value,
            )
        )
        response_proto = self._call_endpoint(CreateGatewayBudgetPolicy, req_body)
        return GatewayBudgetPolicy.from_proto(response_proto.budget_policy)

    def get_budget_policy(
        self,
        budget_policy_id: str,
    ) -> GatewayBudgetPolicy:
        req_body = message_to_json(GetGatewayBudgetPolicy(budget_policy_id=budget_policy_id))
        response_proto = self._call_endpoint(GetGatewayBudgetPolicy, req_body)
        return GatewayBudgetPolicy.from_proto(response_proto.budget_policy)

    def update_budget_policy(
        self,
        budget_policy_id: str,
        budget_unit: BudgetUnit | None = None,
        budget_amount: float | None = None,
        duration: BudgetDuration | None = None,
        target_scope: BudgetTargetScope | None = None,
        budget_action: BudgetAction | None = None,
        updated_by: str | None = None,
        target_value: str | None = None,
    ) -> GatewayBudgetPolicy:
        req_body = message_to_json(
            UpdateGatewayBudgetPolicy(
                budget_policy_id=budget_policy_id,
                budget_unit=budget_unit.to_proto() if budget_unit else None,
                budget_amount=budget_amount,
                duration=duration.to_proto() if duration else None,
                target_scope=target_scope.to_proto() if target_scope else None,
                budget_action=budget_action.to_proto() if budget_action else None,
                updated_by=updated_by,
                target_value=target_value,
            )
        )
        response_proto = self._call_endpoint(UpdateGatewayBudgetPolicy, req_body)
        return GatewayBudgetPolicy.from_proto(response_proto.budget_policy)

    def delete_budget_policy(self, budget_policy_id: str) -> None:
        req_body = message_to_json(DeleteGatewayBudgetPolicy(budget_policy_id=budget_policy_id))
        self._call_endpoint(DeleteGatewayBudgetPolicy, req_body)

    def list_budget_policies(
        self,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        page_token: str | None = None,
    ) -> PagedList[GatewayBudgetPolicy]:
        req_body = message_to_json(
            ListGatewayBudgetPolicies(max_results=max_results, page_token=page_token)
        )
        response_proto = self._call_endpoint(ListGatewayBudgetPolicies, req_body)
        policies = [GatewayBudgetPolicy.from_proto(p) for p in response_proto.budget_policies]
        return PagedList(policies, response_proto.next_page_token or None)

    # ========== Guardrail APIs ==========

    def create_gateway_guardrail(
        self,
        name: str,
        scorer_id: str,
        scorer_version: int,
        stage: GuardrailStage,
        action: GuardrailAction,
        action_endpoint_id: str | None = None,
    ) -> GatewayGuardrail:
        kwargs = {
            "name": name,
            "scorer_id": scorer_id,
            "scorer_version": scorer_version,
            "stage": stage.to_proto(),
            "action": action.to_proto(),
        }
        if action_endpoint_id is not None:
            kwargs["action_endpoint_id"] = action_endpoint_id
        req_body = message_to_json(CreateGatewayGuardrail(**kwargs))
        response_proto = self._call_endpoint(CreateGatewayGuardrail, req_body)
        return GatewayGuardrail.from_proto(response_proto.guardrail)

    def get_gateway_guardrail(self, guardrail_id: str) -> GatewayGuardrail:
        req_body = message_to_json(GetGatewayGuardrail(guardrail_id=guardrail_id))
        response_proto = self._call_endpoint(GetGatewayGuardrail, req_body)
        return GatewayGuardrail.from_proto(response_proto.guardrail)

    def delete_gateway_guardrail(self, guardrail_id: str) -> None:
        req_body = message_to_json(DeleteGatewayGuardrail(guardrail_id=guardrail_id))
        self._call_endpoint(DeleteGatewayGuardrail, req_body)

    def list_gateway_guardrails(
        self,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        page_token: str | None = None,
    ) -> PagedList[GatewayGuardrail]:
        req_body = message_to_json(
            ListGatewayGuardrails(max_results=max_results, page_token=page_token)
        )
        response_proto = self._call_endpoint(ListGatewayGuardrails, req_body)
        guardrails = [GatewayGuardrail.from_proto(g) for g in response_proto.guardrails]
        return PagedList(guardrails, response_proto.next_page_token or None)

    def add_guardrail_to_endpoint(
        self,
        endpoint_id: str,
        guardrail_id: str,
        execution_order: int | None = None,
        created_by: str | None = None,
    ) -> GatewayGuardrailConfig:
        kwargs = {
            "endpoint_id": endpoint_id,
            "guardrail_id": guardrail_id,
        }
        if execution_order is not None:
            kwargs["execution_order"] = execution_order
        req_body = message_to_json(AddGuardrailToEndpoint(**kwargs))
        response_proto = self._call_endpoint(AddGuardrailToEndpoint, req_body)
        return GatewayGuardrailConfig.from_proto(response_proto.config)

    def remove_guardrail_from_endpoint(
        self,
        endpoint_id: str,
        guardrail_id: str,
    ) -> None:
        req_body = message_to_json(
            RemoveGuardrailFromEndpoint(endpoint_id=endpoint_id, guardrail_id=guardrail_id)
        )
        self._call_endpoint(RemoveGuardrailFromEndpoint, req_body)

    def list_endpoint_guardrail_configs(
        self,
        endpoint_id: str,
    ) -> list[GatewayGuardrailConfig]:
        req_body = message_to_json(ListEndpointGuardrailConfigs(endpoint_id=endpoint_id))
        response_proto = self._call_endpoint(ListEndpointGuardrailConfigs, req_body)
        return [GatewayGuardrailConfig.from_proto(c) for c in response_proto.configs]

    def update_endpoint_guardrail_config(
        self,
        endpoint_id: str,
        guardrail_id: str,
        execution_order: int | None = None,
    ) -> GatewayGuardrailConfig:
        kwargs = {"endpoint_id": endpoint_id, "guardrail_id": guardrail_id}
        if execution_order is not None:
            kwargs["execution_order"] = execution_order
        req_body = message_to_json(UpdateEndpointGuardrailConfig(**kwargs))
        response_proto = self._call_endpoint(UpdateEndpointGuardrailConfig, req_body)
        return GatewayGuardrailConfig.from_proto(response_proto.config)
