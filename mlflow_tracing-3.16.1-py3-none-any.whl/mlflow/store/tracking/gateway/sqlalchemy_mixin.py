from __future__ import annotations

import json
import os
import uuid
from typing import Any

from sqlalchemy import case, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import aliased, joinedload

from mlflow.entities import (
    FallbackConfig,
    GatewayEndpoint,
    GatewayEndpointBinding,
    GatewayEndpointModelConfig,
    GatewayEndpointModelMapping,
    GatewayEndpointTag,
    GatewayModelDefinition,
    GatewaySecretInfo,
    RoutingStrategy,
)
from mlflow.entities.experiment_tag import ExperimentTag
from mlflow.entities.gateway_budget_policy import (
    BudgetAction,
    BudgetDuration,
    BudgetTargetScope,
    BudgetUnit,
    GatewayBudgetPolicy,
)
from mlflow.entities.gateway_endpoint import GatewayModelLinkageType
from mlflow.entities.gateway_guardrail import (
    GatewayGuardrail,
    GatewayGuardrailConfig,
    GuardrailAction,
    GuardrailStage,
)
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import (
    INVALID_PARAMETER_VALUE,
    INVALID_STATE,
    RESOURCE_ALREADY_EXISTS,
    RESOURCE_DOES_NOT_EXIST,
    ErrorCode,
)
from mlflow.store.entities.paged_list import PagedList
from mlflow.store.tracking import SEARCH_MAX_RESULTS_DEFAULT
from mlflow.store.tracking._secret_cache import (
    _DEFAULT_CACHE_MAX_SIZE,
    _DEFAULT_CACHE_TTL,
    SECRETS_CACHE_MAX_SIZE_ENV_VAR,
    SECRETS_CACHE_TTL_ENV_VAR,
    SecretCache,
)
from mlflow.store.tracking.dbmodels.models import (
    SqlExperiment,
    SqlGatewayBudgetPolicy,
    SqlGatewayEndpoint,
    SqlGatewayEndpointBinding,
    SqlGatewayEndpointModelMapping,
    SqlGatewayEndpointTag,
    SqlGatewayGuardrail,
    SqlGatewayGuardrailConfig,
    SqlGatewayModelDefinition,
    SqlGatewaySecret,
    SqlSpanMetrics,
    SqlTraceInfo,
    SqlTraceMetadata,
)
from mlflow.telemetry.events import (
    GatewayCreateBudgetPolicyEvent,
    GatewayCreateEndpointEvent,
    GatewayCreateGuardrailEvent,
    GatewayCreateModelDefinitionEvent,
    GatewayCreateSecretEvent,
    GatewayDeleteBudgetPolicyEvent,
    GatewayDeleteEndpointEvent,
    GatewayDeleteGuardrailEvent,
    GatewayDeleteSecretEvent,
    GatewayGetEndpointEvent,
    GatewayListBudgetPoliciesEvent,
    GatewayListEndpointsEvent,
    GatewayListSecretsEvent,
    GatewayUpdateBudgetPolicyEvent,
    GatewayUpdateEndpointEvent,
    GatewayUpdateGuardrailEvent,
    GatewayUpdateSecretEvent,
)
from mlflow.telemetry.track import record_usage_event
from mlflow.tracing.constant import SpanMetricKey, TraceMetadataKey
from mlflow.utils.crypto import (
    KEKManager,
    _encrypt_secret,
    _mask_secret_value,
)
from mlflow.utils.mlflow_tags import (
    MLFLOW_EXPERIMENT_IS_GATEWAY,
    MLFLOW_EXPERIMENT_SOURCE_ID,
    MLFLOW_EXPERIMENT_SOURCE_TYPE,
)
from mlflow.utils.search_utils import SearchUtils
from mlflow.utils.time import get_current_time_millis


def _validate_one_of(
    param1_name: str, param1_value: Any, param2_name: str, param2_value: Any
) -> None:
    """Validate that exactly one of two parameters is provided."""
    if (param1_value is None) == (param2_value is None):
        raise MlflowException(
            f"Exactly one of {param1_name} or {param2_name} must be provided",
            error_code=INVALID_PARAMETER_VALUE,
        )


_TARGETED_BUDGET_SCOPES = (BudgetTargetScope.ENDPOINT.value, BudgetTargetScope.USER.value)


def _normalize_budget_target_value(
    target_scope: str | None, target_value: str | None
) -> str | None:
    """Enforce the budget policy target_value/target_scope invariant at the store layer.

    ENDPOINT- and USER-scoped policies must carry a ``target_value`` (the endpoint ID
    or username to match; without one the policy silently never matches any request
    and thus never enforces). Policies with any other scope must not carry one, so a
    stray ``target_value`` is dropped. This mirrors the REST handler validation so
    direct/programmatic store callers cannot persist a policy that violates the
    invariant.
    """
    if target_scope in _TARGETED_BUDGET_SCOPES:
        if not target_value:
            raise MlflowException(
                message=f"target_value is required when target_scope is {target_scope}.",
                error_code=INVALID_PARAMETER_VALUE,
            )
        return target_value
    return None


class SqlAlchemyGatewayStoreMixin:
    """Mixin class providing SQLAlchemy Gateway implementations for tracking stores.

    This mixin adds Gateway functionality to SQLAlchemy-based tracking stores,
    enabling management of secrets, model definitions, endpoints, and bindings
    for the MLflow AI Gateway.

    Requires the base class to provide:
    - ManagedSessionMaker: Context manager for database sessions
    - _get_entity_or_raise: Helper method for fetching entities or raising if not found
    """

    _secret_cache: SecretCache | None = None

    @property
    def secret_cache(self) -> SecretCache:
        """Lazy-initialized secret cache for endpoint configurations."""
        if self._secret_cache is None:
            ttl = int(os.environ.get(SECRETS_CACHE_TTL_ENV_VAR, _DEFAULT_CACHE_TTL))
            max_size = int(os.environ.get(SECRETS_CACHE_MAX_SIZE_ENV_VAR, _DEFAULT_CACHE_MAX_SIZE))
            self._secret_cache = SecretCache(ttl_seconds=ttl, max_size=max_size)
        return self._secret_cache

    def _get_or_create_experiment_id(self, experiment_name: str, tags=None) -> str:
        """Get an existing experiment ID or create a new experiment if it doesn't exist.

        Args:
            experiment_name: Name of the experiment to get or create.
            tags: Optional list of ExperimentTag instances to set on the experiment.

        Returns:
            The experiment ID.
        """
        try:
            # The class that inherits from this mixin must implement the create_experiment method
            return self.create_experiment(experiment_name, tags=tags)
        except MlflowException as e:
            if e.error_code == ErrorCode.Name(RESOURCE_ALREADY_EXISTS):
                experiment = self.get_experiment_by_name(experiment_name)
                if experiment is not None:
                    return experiment.experiment_id
            raise

    def _get_cache_key(self, resource_type: str, resource_id: str) -> str:
        """Generate cache key for resource endpoint configs."""
        return f"{resource_type}:{resource_id}"

    def _invalidate_secret_cache(self) -> None:
        """Clear the secret cache on mutations."""
        if self._secret_cache is not None:
            self._secret_cache.clear()

    @record_usage_event(GatewayCreateSecretEvent)
    def create_gateway_secret(
        self,
        secret_name: str,
        secret_value: dict[str, str],
        provider: str | None = None,
        auth_config: dict[str, Any] | None = None,
        created_by: str | None = None,
    ) -> GatewaySecretInfo:
        """
        Create a new encrypted secret using envelope encryption.

        Args:
            secret_name: Unique user-friendly name for the secret.
            secret_value: The secret value(s) to encrypt as key-value pairs.
                For simple API keys: {"api_key": "sk-xxx"}
                For compound credentials: {"aws_access_key_id": "...",
                  "aws_secret_access_key": "..."}
            provider: Optional LLM provider (e.g., "openai", "anthropic").
            auth_config: Optional provider-specific auth configuration dict.
                Should include "auth_mode" for providers with multiple auth options.
            created_by: Username of the creator.

        Returns:
            Secret entity with metadata (encrypted value not included).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            secret_id = f"s-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            value_to_encrypt = json.dumps(secret_value)
            masked_value = _mask_secret_value(secret_value)

            kek_manager = KEKManager()

            encrypted = _encrypt_secret(
                secret_value=value_to_encrypt,
                kek_manager=kek_manager,
                secret_id=secret_id,
                secret_name=secret_name,
            )

            sql_secret = self._with_workspace_field(
                SqlGatewaySecret(
                    secret_id=secret_id,
                    secret_name=secret_name,
                    encrypted_value=encrypted.encrypted_value,
                    wrapped_dek=encrypted.wrapped_dek,
                    masked_value=json.dumps(masked_value),
                    kek_version=encrypted.kek_version,
                    provider=provider,
                    auth_config=json.dumps(auth_config) if auth_config else None,
                    created_at=current_time,
                    last_updated_at=current_time,
                    created_by=created_by,
                    last_updated_by=created_by,
                )
            )

            try:
                session.add(sql_secret)
                session.flush()
            except IntegrityError as e:
                raise MlflowException(
                    f"Secret with name '{secret_name}' already exists",
                    error_code=RESOURCE_ALREADY_EXISTS,
                ) from e

            return sql_secret.to_mlflow_entity()

    def get_secret_info(
        self, secret_id: str | None = None, secret_name: str | None = None
    ) -> GatewaySecretInfo:
        """
        Retrieve secret metadata by ID or name (does not decrypt the value and only
        returns the masked secret for the purposes of key identification for users).

        Args:
            secret_id: ID of the secret to retrieve.
            secret_name: Name of the secret to retrieve.

        Returns:
            Secret entity with metadata (encrypted value not included).
        """
        _validate_one_of("secret_id", secret_id, "secret_name", secret_name)

        with self.ManagedSessionMaker() as session:
            if secret_id:
                sql_secret = self._get_entity_or_raise(
                    session, SqlGatewaySecret, {"secret_id": secret_id}, "GatewaySecret"
                )
            else:
                sql_secret = self._get_entity_or_raise(
                    session, SqlGatewaySecret, {"secret_name": secret_name}, "GatewaySecret"
                )

            return sql_secret.to_mlflow_entity()

    @record_usage_event(GatewayUpdateSecretEvent)
    def update_gateway_secret(
        self,
        secret_id: str,
        secret_value: dict[str, str] | None = None,
        auth_config: dict[str, Any] | None = None,
        updated_by: str | None = None,
    ) -> GatewaySecretInfo:
        """
        Update an existing secret's configuration.

        Args:
            secret_id: ID of the secret to update.
            secret_value: Optional new secret value(s) for key rotation as key-value pairs,
                or None to leave unchanged.
                For simple API keys: {"api_key": "sk-xxx"}
                For compound credentials: {"aws_access_key_id": "...",
                  "aws_secret_access_key": "..."}
            auth_config: Optional updated auth configuration. If provided, replaces existing
                auth_config. If None, auth_config is unchanged. If empty dict, clears auth_config.
            updated_by: Username of the updater.

        Returns:
            Updated Secret entity.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_secret = self._get_entity_or_raise(
                session, SqlGatewaySecret, {"secret_id": secret_id}, "GatewaySecret"
            )

            if secret_value is not None:
                value_to_encrypt = json.dumps(secret_value)
                masked_value = _mask_secret_value(secret_value)

                kek_manager = KEKManager()

                encrypted = _encrypt_secret(
                    secret_value=value_to_encrypt,
                    kek_manager=kek_manager,
                    secret_id=sql_secret.secret_id,
                    secret_name=sql_secret.secret_name,
                )

                sql_secret.encrypted_value = encrypted.encrypted_value
                sql_secret.wrapped_dek = encrypted.wrapped_dek
                sql_secret.kek_version = encrypted.kek_version
                sql_secret.masked_value = json.dumps(masked_value)

            if auth_config is not None:
                # Empty dict {} explicitly clears auth_config, non-empty dict replaces it
                sql_secret.auth_config = json.dumps(auth_config) if auth_config else None

            sql_secret.last_updated_by = updated_by
            sql_secret.last_updated_at = get_current_time_millis()

            session.flush()
            session.refresh(sql_secret)

            self._invalidate_secret_cache()
            return sql_secret.to_mlflow_entity()

    @record_usage_event(GatewayDeleteSecretEvent)
    def delete_gateway_secret(self, secret_id: str) -> None:
        """
        Permanently delete a secret.

        Model definitions that reference this secret will become orphaned (their
        secret_id will be set to NULL). They can still be used but will need to
        be updated with a new secret before they can be used for LLM calls.

        Args:
            secret_id: ID of the secret to delete.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_secret = self._get_entity_or_raise(
                session, SqlGatewaySecret, {"secret_id": secret_id}, "GatewaySecret"
            )

            session.delete(sql_secret)
            self._invalidate_secret_cache()

    @record_usage_event(GatewayListSecretsEvent)
    def list_secret_infos(self, provider: str | None = None) -> list[GatewaySecretInfo]:
        """
        List all secret metadata with optional filtering.

        Args:
            provider: Optional filter by LLM provider (e.g., "openai", "anthropic").

        Returns:
            List of Secret entities with metadata (encrypted values not included).
        """
        with self.ManagedSessionMaker() as session:
            query = self._get_query(session, SqlGatewaySecret)

            if provider is not None:
                query = query.filter(SqlGatewaySecret.provider == provider)

            sql_secrets = query.all()
            return [secret.to_mlflow_entity() for secret in sql_secrets]

    @record_usage_event(GatewayCreateModelDefinitionEvent)
    def create_gateway_model_definition(
        self,
        name: str,
        secret_id: str,
        provider: str,
        model_name: str,
        created_by: str | None = None,
    ) -> GatewayModelDefinition:
        """
        Create a reusable model definition.

        Args:
            name: User-friendly name for identification and reuse. Must be unique.
            secret_id: ID of the secret containing authentication credentials.
            provider: LLM provider (e.g., "openai", "anthropic", "cohere", "bedrock").
            model_name: Provider-specific model identifier (e.g., "gpt-4o").
            created_by: Username of the creator.

        Returns:
            GatewayModelDefinition entity with metadata.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_secret = self._get_entity_or_raise(
                session, SqlGatewaySecret, {"secret_id": secret_id}, "GatewaySecret"
            )

            model_definition_id = f"d-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            sql_model_def = self._with_workspace_field(
                SqlGatewayModelDefinition(
                    model_definition_id=model_definition_id,
                    name=name,
                    secret_id=secret_id,
                    provider=provider,
                    model_name=model_name,
                    created_at=current_time,
                    last_updated_at=current_time,
                    created_by=created_by,
                    last_updated_by=created_by,
                )
            )

            try:
                session.add(sql_model_def)
                session.flush()
            except IntegrityError as e:
                raise MlflowException(
                    f"Model definition with name '{name}' already exists",
                    error_code=RESOURCE_ALREADY_EXISTS,
                ) from e

            session.refresh(sql_model_def)

            return GatewayModelDefinition(
                model_definition_id=sql_model_def.model_definition_id,
                name=sql_model_def.name,
                secret_id=sql_model_def.secret_id,
                secret_name=sql_secret.secret_name,
                provider=sql_model_def.provider,
                model_name=sql_model_def.model_name,
                created_at=sql_model_def.created_at,
                last_updated_at=sql_model_def.last_updated_at,
                created_by=sql_model_def.created_by,
                last_updated_by=sql_model_def.last_updated_by,
            )

    def get_gateway_model_definition(
        self, model_definition_id: str | None = None, name: str | None = None
    ) -> GatewayModelDefinition:
        """
        Retrieve a model definition by ID or name.

        Args:
            model_definition_id: ID of the model definition to retrieve.
            name: Name of the model definition to retrieve.

        Returns:
            GatewayModelDefinition entity with metadata.
        """
        _validate_one_of("model_definition_id", model_definition_id, "name", name)

        with self.ManagedSessionMaker() as session:
            if model_definition_id:
                sql_model_def = self._get_entity_or_raise(
                    session,
                    SqlGatewayModelDefinition,
                    {"model_definition_id": model_definition_id},
                    "GatewayModelDefinition",
                )
            else:
                sql_model_def = self._get_entity_or_raise(
                    session, SqlGatewayModelDefinition, {"name": name}, "GatewayModelDefinition"
                )

            return sql_model_def.to_mlflow_entity()

    def list_gateway_model_definitions(
        self,
        provider: str | None = None,
        secret_id: str | None = None,
    ) -> list[GatewayModelDefinition]:
        """
        List all model definitions with optional filtering.

        Args:
            provider: Optional filter by LLM provider.
            secret_id: Optional filter by secret ID.

        Returns:
            List of GatewayModelDefinition entities with metadata.
        """
        with self.ManagedSessionMaker() as session:
            query = self._get_query(session, SqlGatewayModelDefinition)

            if provider is not None:
                query = query.filter(SqlGatewayModelDefinition.provider == provider)
            if secret_id is not None:
                query = query.filter(SqlGatewayModelDefinition.secret_id == secret_id)

            sql_model_defs = query.all()
            return [model_def.to_mlflow_entity() for model_def in sql_model_defs]

    def update_gateway_model_definition(
        self,
        model_definition_id: str,
        name: str | None = None,
        secret_id: str | None = None,
        model_name: str | None = None,
        updated_by: str | None = None,
        provider: str | None = None,
    ) -> GatewayModelDefinition:
        """
        Update a model definition.

        Args:
            model_definition_id: ID of the model definition to update.
            name: Optional new name.
            secret_id: Optional new secret ID.
            model_name: Optional new model name.
            updated_by: Username of the updater.
            provider: Optional new provider.

        Returns:
            Updated GatewayModelDefinition entity.

        Raises:
            MlflowException: If the model definition or secret is not found
                (RESOURCE_DOES_NOT_EXIST), or if the new name conflicts with an existing
                model definition (RESOURCE_ALREADY_EXISTS).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_model_def = self._get_entity_or_raise(
                session,
                SqlGatewayModelDefinition,
                {"model_definition_id": model_definition_id},
                "GatewayModelDefinition",
            )

            if name is not None:
                sql_model_def.name = name
            if secret_id is not None:
                self._get_entity_or_raise(
                    session, SqlGatewaySecret, {"secret_id": secret_id}, "GatewaySecret"
                )
                sql_model_def.secret_id = secret_id
            if model_name is not None:
                sql_model_def.model_name = model_name
            if provider is not None:
                sql_model_def.provider = provider

            sql_model_def.last_updated_at = get_current_time_millis()
            if updated_by:
                sql_model_def.last_updated_by = updated_by

            try:
                session.flush()
            except IntegrityError as e:
                raise MlflowException(
                    f"Model definition with name '{name}' already exists",
                    error_code=RESOURCE_ALREADY_EXISTS,
                ) from e

            session.refresh(sql_model_def)

            self._invalidate_secret_cache()
            return sql_model_def.to_mlflow_entity()

    def delete_gateway_model_definition(self, model_definition_id: str) -> None:
        """
        Delete a model definition.

        Fails with an error if the model definition is currently attached to any
        endpoints (RESTRICT behavior enforced by database constraint).

        Args:
            model_definition_id: ID of the model definition to delete.

        Raises:
            MlflowException: If the model definition is not found (RESOURCE_DOES_NOT_EXIST),
                or if it is currently in use by endpoints (INVALID_STATE).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_model_def = self._get_entity_or_raise(
                session,
                SqlGatewayModelDefinition,
                {"model_definition_id": model_definition_id},
                "GatewayModelDefinition",
            )

            try:
                session.delete(sql_model_def)
                session.flush()
                self._invalidate_secret_cache()
            except IntegrityError as e:
                raise MlflowException(
                    "Cannot delete model definition that is currently in use by endpoints. "
                    "Detach it from all endpoints first.",
                    error_code=INVALID_STATE,
                ) from e

    @record_usage_event(GatewayCreateEndpointEvent)
    def create_gateway_endpoint(
        self,
        name: str,
        model_configs: list[GatewayEndpointModelConfig],
        created_by: str | None = None,
        routing_strategy: RoutingStrategy | None = None,
        fallback_config: FallbackConfig | None = None,
        experiment_id: str | None = None,
        usage_tracking: bool = True,
    ) -> GatewayEndpoint:
        """
        Create a new endpoint with references to existing model definitions.

        Args:
            name: User-friendly name for the endpoint.
            model_configs: List of model configurations for each model.
                          At least one model configuration with PRIMARY linkage type is required.
            created_by: Username of the creator.
            routing_strategy: Routing strategy for the endpoint.
            fallback_config: Fallback configuration (includes strategy and max_attempts).
            experiment_id: ID of the MLflow experiment where traces are logged.
                          Only used when usage_tracking is True. If not provided
                          and usage_tracking is True, an experiment will be auto-created
                          with name 'gateway/{endpoint_name}'.
            usage_tracking: Whether to enable usage tracking for this endpoint.
                           When True, traces will be logged for endpoint invocations.

        Returns:
            Endpoint entity with model_mappings populated.

        Raises:
            MlflowException: If model_configs list is empty (INVALID_PARAMETER_VALUE),
                or if any referenced model definition does not exist (RESOURCE_DOES_NOT_EXIST).
        """
        if not model_configs:
            raise MlflowException(
                "Endpoint must have at least one model configuration",
                error_code=INVALID_PARAMETER_VALUE,
            )

        with self.ManagedSessionMaker(read_only=False) as session:
            # Validate all model definitions exist
            all_model_def_ids = {config.model_definition_id for config in model_configs}

            existing_model_defs = (
                self
                ._get_query(session, SqlGatewayModelDefinition)
                .filter(SqlGatewayModelDefinition.model_definition_id.in_(all_model_def_ids))
                .all()
            )
            existing_ids = {m.model_definition_id for m in existing_model_defs}
            if missing := all_model_def_ids - existing_ids:
                raise MlflowException(
                    f"Model definitions not found: {', '.join(missing)}",
                    error_code=RESOURCE_DOES_NOT_EXIST,
                )

            endpoint_id = f"e-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            # Auto-create experiment if usage_tracking is enabled and no experiment_id provided
            if usage_tracking and experiment_id is None:
                experiment_id = self._get_or_create_experiment_id(
                    f"gateway/{name}",
                    tags=[
                        ExperimentTag(MLFLOW_EXPERIMENT_SOURCE_TYPE, "GATEWAY"),
                        ExperimentTag(MLFLOW_EXPERIMENT_SOURCE_ID, endpoint_id),
                        ExperimentTag(MLFLOW_EXPERIMENT_IS_GATEWAY, "true"),
                    ],
                )

            # Build fallback_config_json if fallback_config provided or fallback models exist
            fallback_model_def_ids = [
                config.model_definition_id
                for config in model_configs
                if config.linkage_type == GatewayModelLinkageType.FALLBACK
            ]
            fallback_config_json = None
            if fallback_config or fallback_model_def_ids:
                fallback_config_json = json.dumps({
                    "strategy": fallback_config.strategy.value
                    if fallback_config and fallback_config.strategy
                    else None,
                    "max_attempts": fallback_config.max_attempts if fallback_config else None,
                    "model_definition_ids": fallback_model_def_ids,
                })

            sql_endpoint = self._with_workspace_field(
                SqlGatewayEndpoint(
                    endpoint_id=endpoint_id,
                    name=name,
                    created_at=current_time,
                    last_updated_at=current_time,
                    created_by=created_by,
                    last_updated_by=created_by,
                    routing_strategy=routing_strategy.value if routing_strategy else None,
                    fallback_config_json=fallback_config_json,
                    experiment_id=int(experiment_id) if experiment_id else None,
                    usage_tracking=usage_tracking,
                )
            )
            session.add(sql_endpoint)

            # Create mappings for all model configs
            for config in model_configs:
                mapping_id = f"m-{uuid.uuid4().hex}"
                sql_mapping = SqlGatewayEndpointModelMapping(
                    mapping_id=mapping_id,
                    endpoint_id=endpoint_id,
                    model_definition_id=config.model_definition_id,
                    weight=config.weight,
                    linkage_type=config.linkage_type.value,
                    fallback_order=config.fallback_order,
                    created_at=current_time,
                    created_by=created_by,
                )
                session.add(sql_mapping)

            session.flush()
            session.refresh(sql_endpoint)

            return sql_endpoint.to_mlflow_entity()

    @record_usage_event(GatewayGetEndpointEvent)
    def get_gateway_endpoint(
        self, endpoint_id: str | None = None, name: str | None = None
    ) -> GatewayEndpoint:
        """
        Retrieve an endpoint by ID or name with its model mappings populated.

        Args:
            endpoint_id: ID of the endpoint to retrieve.
            name: Name of the endpoint to retrieve.

        Returns:
            Endpoint entity with model_mappings list populated.

        Raises:
            MlflowException: If exactly one of endpoint_id or name is not provided
                (INVALID_PARAMETER_VALUE), or if the endpoint is not found
                (RESOURCE_DOES_NOT_EXIST).
        """
        _validate_one_of("endpoint_id", endpoint_id, "name", name)

        with self.ManagedSessionMaker() as session:
            if endpoint_id:
                sql_endpoint = self._get_entity_or_raise(
                    session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
                )
            else:
                sql_endpoint = self._get_entity_or_raise(
                    session, SqlGatewayEndpoint, {"name": name}, "GatewayEndpoint"
                )

            return sql_endpoint.to_mlflow_entity()

    @record_usage_event(GatewayUpdateEndpointEvent)
    def update_gateway_endpoint(
        self,
        endpoint_id: str,
        name: str | None = None,
        updated_by: str | None = None,
        routing_strategy: RoutingStrategy | None = None,
        fallback_config: FallbackConfig | None = None,
        model_configs: list[GatewayEndpointModelConfig] | None = None,
        experiment_id: str | None = None,
        usage_tracking: bool | None = None,
    ) -> GatewayEndpoint:
        """
        Update an endpoint's configuration.

        Args:
            endpoint_id: ID of the endpoint to update.
            name: Optional new name for the endpoint.
            updated_by: Optional username of the updater.
            routing_strategy: Optional new routing strategy.
            fallback_config: Optional fallback configuration (includes strategy and max_attempts).
            model_configs: Optional new list of model configurations (replaces all linkages).
            experiment_id: Optional new experiment ID for tracing.
            usage_tracking: Optional flag to enable/disable usage tracking.

        Returns:
            Updated Endpoint entity.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_endpoint = self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )

            if name is not None:
                sql_endpoint.name = name

            # Handle usage_tracking update
            if usage_tracking is not None:
                sql_endpoint.usage_tracking = usage_tracking

            # Auto-create experiment if usage_tracking is enabled and no experiment_id provided
            if usage_tracking and experiment_id is None and sql_endpoint.experiment_id is None:
                endpoint_name = name if name is not None else sql_endpoint.name
                experiment_id = self._get_or_create_experiment_id(
                    f"gateway/{endpoint_name}",
                    tags=[
                        ExperimentTag(MLFLOW_EXPERIMENT_SOURCE_TYPE, "GATEWAY"),
                        ExperimentTag(MLFLOW_EXPERIMENT_SOURCE_ID, endpoint_id),
                        ExperimentTag(MLFLOW_EXPERIMENT_IS_GATEWAY, "true"),
                    ],
                )

            if experiment_id is not None:
                sql_endpoint.experiment_id = int(experiment_id)

            if routing_strategy is not None:
                sql_endpoint.routing_strategy = routing_strategy.value

            # Replace model linkages if model_configs provided
            if model_configs is not None:
                # Validate all model definitions exist
                all_model_def_ids = {config.model_definition_id for config in model_configs}
                for model_def_id in all_model_def_ids:
                    self._get_entity_or_raise(
                        session,
                        SqlGatewayModelDefinition,
                        {"model_definition_id": model_def_id},
                        "GatewayModelDefinition",
                    )

                # Delete all existing linkages
                session.query(SqlGatewayEndpointModelMapping).filter(
                    SqlGatewayEndpointModelMapping.endpoint_id == endpoint_id,
                ).delete()

                # Create new linkages from model_configs
                for config in model_configs:
                    sql_mapping = SqlGatewayEndpointModelMapping(
                        mapping_id=f"m-{uuid.uuid4().hex}",
                        endpoint_id=endpoint_id,
                        model_definition_id=config.model_definition_id,
                        weight=config.weight,
                        linkage_type=config.linkage_type.value,
                        fallback_order=config.fallback_order,
                        created_at=get_current_time_millis(),
                        created_by=updated_by,
                    )
                    session.add(sql_mapping)

                # Update fallback_config_json with new fallback model IDs
                fallback_model_def_ids = [
                    config.model_definition_id
                    for config in model_configs
                    if config.linkage_type == GatewayModelLinkageType.FALLBACK
                ]
                sql_endpoint.fallback_config_json = json.dumps({
                    "strategy": fallback_config.strategy.value
                    if fallback_config and fallback_config.strategy
                    else None,
                    "max_attempts": fallback_config.max_attempts if fallback_config else None,
                    "model_definition_ids": fallback_model_def_ids,
                })

            # Update fallback_config_json if only fallback_config provided (without model_configs)
            elif fallback_config is not None:
                # Keep existing model definition IDs from current config
                existing_config = (
                    json.loads(sql_endpoint.fallback_config_json)
                    if sql_endpoint.fallback_config_json
                    else {}
                )
                sql_endpoint.fallback_config_json = json.dumps({
                    "strategy": fallback_config.strategy.value
                    if fallback_config.strategy
                    else None,
                    "max_attempts": fallback_config.max_attempts,
                    "model_definition_ids": existing_config.get("model_definition_ids", []),
                })

            sql_endpoint.last_updated_at = get_current_time_millis()
            if updated_by:
                sql_endpoint.last_updated_by = updated_by

            session.flush()
            session.refresh(sql_endpoint)

            self._invalidate_secret_cache()
            return sql_endpoint.to_mlflow_entity()

    @record_usage_event(GatewayDeleteEndpointEvent)
    def delete_gateway_endpoint(self, endpoint_id: str) -> None:
        """
        Delete an endpoint (CASCADE deletes bindings and model mappings).

        Args:
            endpoint_id: ID of the endpoint to delete.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_endpoint = self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )

            session.delete(sql_endpoint)
            self._invalidate_secret_cache()

    @record_usage_event(GatewayListEndpointsEvent)
    def list_gateway_endpoints(
        self,
        provider: str | None = None,
        secret_id: str | None = None,
    ) -> list[GatewayEndpoint]:
        """
        List all endpoints with their model mappings populated.

        Args:
            provider: Optional filter by LLM provider (e.g., "openai", "anthropic").
                Returns only endpoints that have at least one model from this provider.
            secret_id: Optional filter by secret ID. Returns only endpoints using this secret.
                Useful for showing which endpoints would be affected by secret deletion.

        Returns:
            List of Endpoint entities with model_mappings.
        """
        with self.ManagedSessionMaker() as session:
            query = self._get_query(session, SqlGatewayEndpoint).join(
                SqlGatewayEndpointModelMapping
            )

            if provider or secret_id:
                query = query.join(
                    SqlGatewayModelDefinition,
                    SqlGatewayEndpointModelMapping.model_definition_id
                    == SqlGatewayModelDefinition.model_definition_id,
                )

                if provider:
                    query = query.filter(SqlGatewayModelDefinition.provider == provider)
                if secret_id:
                    query = query.filter(SqlGatewayModelDefinition.secret_id == secret_id)

            endpoints = query.distinct().all()
            return [endpoint.to_mlflow_entity() for endpoint in endpoints]

    def attach_model_to_endpoint(
        self,
        endpoint_id: str,
        model_config: GatewayEndpointModelConfig,
        created_by: str | None = None,
    ) -> GatewayEndpointModelMapping:
        """
        Attach an existing model definition to an endpoint.

        Args:
            endpoint_id: ID of the endpoint to attach the model to.
            model_config: Configuration for the model to attach.
            created_by: Username of the creator.

        Returns:
            EndpointModelMapping entity.

        Raises:
            MlflowException: If the endpoint or model definition is not found
                (RESOURCE_DOES_NOT_EXIST), or if the model definition is already
                attached to this endpoint with the same linkage_type (RESOURCE_ALREADY_EXISTS).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_endpoint = self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )
            self._get_entity_or_raise(
                session,
                SqlGatewayModelDefinition,
                {"model_definition_id": model_config.model_definition_id},
                "GatewayModelDefinition",
            )

            mapping_id = f"m-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            sql_mapping = SqlGatewayEndpointModelMapping(
                mapping_id=mapping_id,
                endpoint_id=endpoint_id,
                model_definition_id=model_config.model_definition_id,
                weight=model_config.weight,
                linkage_type=model_config.linkage_type.value,
                fallback_order=model_config.fallback_order,
                created_at=current_time,
                created_by=created_by,
            )

            sql_endpoint.last_updated_at = current_time
            if created_by:
                sql_endpoint.last_updated_by = created_by

            try:
                session.add(sql_mapping)
                session.flush()
            except IntegrityError as e:
                raise MlflowException(
                    f"Model definition '{model_config.model_definition_id}' is already attached to "
                    f"endpoint '{endpoint_id}'",
                    error_code=RESOURCE_ALREADY_EXISTS,
                ) from e

            session.refresh(sql_mapping)

            self._invalidate_secret_cache()
            return sql_mapping.to_mlflow_entity()

    def detach_model_from_endpoint(
        self,
        endpoint_id: str,
        model_definition_id: str,
        linkage_type: str | None = None,
    ) -> None:
        """
        Detach a model definition from an endpoint.

        This removes the mapping but does not delete the model definition itself.

        Args:
            endpoint_id: ID of the endpoint.
            model_definition_id: ID of the model definition to detach.
            linkage_type: Optional linkage type filter. If not provided, detaches all linkages
                         for this endpoint-model pair.

        Raises:
            MlflowException: If the mapping is not found (RESOURCE_DOES_NOT_EXIST).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            query = self._get_query(session, SqlGatewayEndpointModelMapping).filter(
                SqlGatewayEndpointModelMapping.endpoint_id == endpoint_id,
                SqlGatewayEndpointModelMapping.model_definition_id == model_definition_id,
            )
            if linkage_type:
                query = query.filter(SqlGatewayEndpointModelMapping.linkage_type == linkage_type)

            sql_mapping = query.first()
            if not sql_mapping:
                sql_endpoint = (
                    self
                    ._get_query(session, SqlGatewayEndpoint)
                    .filter(SqlGatewayEndpoint.endpoint_id == endpoint_id)
                    .first()
                )
                if not sql_endpoint:
                    raise MlflowException(
                        f"GatewayEndpoint not found (endpoint_id='{endpoint_id}')",
                        error_code=RESOURCE_DOES_NOT_EXIST,
                    )
                linkage_str = f" with linkage type '{linkage_type}'" if linkage_type else ""
                raise MlflowException(
                    f"Model definition '{model_definition_id}' is not attached to "
                    f"endpoint '{endpoint_id}'{linkage_str}",
                    error_code=RESOURCE_DOES_NOT_EXIST,
                )

            session.delete(sql_mapping)
            self._invalidate_secret_cache()

    def create_endpoint_binding(
        self,
        endpoint_id: str,
        resource_type: str,
        resource_id: str,
        created_by: str | None = None,
    ) -> GatewayEndpointBinding:
        """
        Bind an endpoint to an MLflow resource.

        Args:
            endpoint_id: ID of the endpoint to bind.
            resource_type: Type of resource (e.g., "scorer").
            resource_id: Unique identifier for the resource instance.
            created_by: Username of the creator.

        Returns:
            GatewayEndpointBinding entity.

        Raises:
            MlflowException: If the endpoint is not found (RESOURCE_DOES_NOT_EXIST).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )

            current_time = get_current_time_millis()

            sql_binding = SqlGatewayEndpointBinding(
                endpoint_id=endpoint_id,
                resource_type=resource_type,
                resource_id=resource_id,
                created_at=current_time,
                last_updated_at=current_time,
                created_by=created_by,
                last_updated_by=created_by,
            )

            session.add(sql_binding)
            session.flush()
            session.refresh(sql_binding)

            self._invalidate_secret_cache()
            return sql_binding.to_mlflow_entity()

    def delete_endpoint_binding(
        self, endpoint_id: str, resource_type: str, resource_id: str
    ) -> None:
        """
        Delete an endpoint binding.

        Args:
            endpoint_id: ID of the endpoint.
            resource_type: Type of resource bound to the endpoint.
            resource_id: ID of the resource.

        Raises:
            MlflowException: If the binding is not found (RESOURCE_DOES_NOT_EXIST).
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_binding = self._get_entity_or_raise(
                session,
                SqlGatewayEndpointBinding,
                {
                    "endpoint_id": endpoint_id,
                    "resource_type": resource_type,
                    "resource_id": resource_id,
                },
                "GatewayEndpointBinding",
            )

            session.delete(sql_binding)
            self._invalidate_secret_cache()

    def list_endpoint_bindings(
        self,
        endpoint_id: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
    ) -> list[GatewayEndpointBinding]:
        """
        List endpoint bindings with optional filtering.

        Args:
            endpoint_id: Optional filter by endpoint ID.
            resource_type: Optional filter by resource type.
            resource_id: Optional filter by resource ID.

        Returns:
            List of GatewayEndpointBinding entities (with endpoint_name and
            model_mappings populated).
        """
        with self.ManagedSessionMaker() as session:
            query = self._get_query(session, SqlGatewayEndpointBinding).options(
                joinedload(SqlGatewayEndpointBinding.endpoint).joinedload(
                    SqlGatewayEndpoint.model_mappings
                )
            )

            if endpoint_id is not None:
                query = query.filter(SqlGatewayEndpointBinding.endpoint_id == endpoint_id)
            if resource_type is not None:
                query = query.filter(SqlGatewayEndpointBinding.resource_type == resource_type)
            if resource_id is not None:
                query = query.filter(SqlGatewayEndpointBinding.resource_id == resource_id)

            bindings = query.all()
            return [binding.to_mlflow_entity() for binding in bindings]

    def set_gateway_endpoint_tag(
        self,
        endpoint_id: str,
        tag: GatewayEndpointTag,
    ) -> None:
        """
        Set a tag on an endpoint.

        Args:
            endpoint_id: ID of the endpoint to tag.
            tag: GatewayEndpointTag with key and value to set.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )
            session.merge(
                SqlGatewayEndpointTag(
                    endpoint_id=endpoint_id,
                    key=tag.key,
                    value=tag.value,
                )
            )

    def delete_gateway_endpoint_tag(
        self,
        endpoint_id: str,
        key: str,
    ) -> None:
        """
        Delete a tag from an endpoint.

        Args:
            endpoint_id: ID of the endpoint.
            key: Tag key to delete.
        """
        with self.ManagedSessionMaker(read_only=False) as session:
            self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "GatewayEndpoint"
            )
            session.query(SqlGatewayEndpointTag).filter(
                SqlGatewayEndpointTag.endpoint_id == endpoint_id,
                SqlGatewayEndpointTag.key == key,
            ).delete()

    # Budget Policy APIs

    @record_usage_event(GatewayCreateBudgetPolicyEvent)
    def create_budget_policy(
        self,
        budget_unit: BudgetUnit,
        budget_amount: float,
        duration: BudgetDuration,
        target_scope: BudgetTargetScope,
        budget_action: BudgetAction,
        created_by: str | None = None,
        target_value: str | None = None,
    ) -> GatewayBudgetPolicy:
        scope_value = (
            target_scope.value if isinstance(target_scope, BudgetTargetScope) else target_scope
        )
        target_value = _normalize_budget_target_value(scope_value, target_value)
        with self.ManagedSessionMaker(read_only=False) as session:
            if scope_value == BudgetTargetScope.ENDPOINT.value:
                # An ENDPOINT policy referencing a nonexistent endpoint would never
                # match any request (a REJECT cap that silently never rejects), so
                # require the endpoint to exist up front. USER targets are free-form
                # usernames and are not validated against any table.
                self._get_entity_or_raise(
                    session, SqlGatewayEndpoint, {"endpoint_id": target_value}, "GatewayEndpoint"
                )
            budget_policy_id = f"bp-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            sql_budget_policy = self._with_workspace_field(
                SqlGatewayBudgetPolicy(
                    budget_policy_id=budget_policy_id,
                    budget_unit=budget_unit.value
                    if isinstance(budget_unit, BudgetUnit)
                    else budget_unit,
                    budget_amount=budget_amount,
                    duration_unit=duration.unit.value,
                    duration_value=duration.value,
                    target_scope=scope_value,
                    budget_action=budget_action.value
                    if isinstance(budget_action, BudgetAction)
                    else budget_action,
                    created_at=current_time,
                    last_updated_at=current_time,
                    created_by=created_by,
                    last_updated_by=created_by,
                    target_value=target_value,
                )
            )

            session.add(sql_budget_policy)
            session.flush()

            return sql_budget_policy.to_mlflow_entity()

    def get_budget_policy(
        self,
        budget_policy_id: str,
    ) -> GatewayBudgetPolicy:
        with self.ManagedSessionMaker() as session:
            sql_budget_policy = self._get_entity_or_raise(
                session,
                SqlGatewayBudgetPolicy,
                {"budget_policy_id": budget_policy_id},
                "BudgetPolicy",
            )
            return sql_budget_policy.to_mlflow_entity()

    @record_usage_event(GatewayUpdateBudgetPolicyEvent)
    def update_budget_policy(
        self,
        budget_policy_id: str,
        budget_unit: BudgetUnit | None = None,
        budget_amount: float | None = None,
        duration: BudgetDuration | None = None,
        target_scope: BudgetTargetScope | None = None,
        budget_action: BudgetAction | None = None,
        updated_by: str | None = None,
        target_value: str | None = None,
    ) -> GatewayBudgetPolicy:
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_budget_policy = self._get_entity_or_raise(
                session,
                SqlGatewayBudgetPolicy,
                {"budget_policy_id": budget_policy_id},
                "BudgetPolicy",
            )

            if budget_unit is not None:
                sql_budget_policy.budget_unit = (
                    budget_unit.value if isinstance(budget_unit, BudgetUnit) else budget_unit
                )
            if budget_amount is not None:
                sql_budget_policy.budget_amount = budget_amount
            if duration is not None:
                sql_budget_policy.duration_unit = duration.unit.value
                sql_budget_policy.duration_value = duration.value
            if target_scope is not None:
                scope_value = (
                    target_scope.value
                    if isinstance(target_scope, BudgetTargetScope)
                    else target_scope
                )
                # A target only makes sense within the scope it was written for (an
                # endpoint ID is meaningless as a username and vice versa), so a scope
                # switch never silently adopts the previous target; the caller must
                # provide a new one.
                if scope_value != sql_budget_policy.target_scope:
                    sql_budget_policy.target_value = None
                sql_budget_policy.target_scope = scope_value
            if budget_action is not None:
                sql_budget_policy.budget_action = (
                    budget_action.value
                    if isinstance(budget_action, BudgetAction)
                    else budget_action
                )
            if target_value is not None:
                sql_budget_policy.target_value = target_value
            # Enforce the target_value/scope invariant on the resulting row: ENDPOINT-
            # and USER-scoped policies must always carry a target (a targeted policy
            # with target_value=None silently never matches any request, so reject it
            # rather than persist a dead policy), and any other scope must not.
            sql_budget_policy.target_value = _normalize_budget_target_value(
                sql_budget_policy.target_scope, sql_budget_policy.target_value
            )
            # An ENDPOINT target must reference an existing endpoint; validate whenever
            # this update introduced or changed it. USER targets are free-form
            # usernames and are not validated against any table.
            if (
                target_value is not None
                and sql_budget_policy.target_scope == BudgetTargetScope.ENDPOINT.value
            ):
                self._get_entity_or_raise(
                    session,
                    SqlGatewayEndpoint,
                    {"endpoint_id": sql_budget_policy.target_value},
                    "GatewayEndpoint",
                )

            sql_budget_policy.last_updated_at = get_current_time_millis()
            if updated_by is not None:
                sql_budget_policy.last_updated_by = updated_by

            session.flush()

            return sql_budget_policy.to_mlflow_entity()

    @record_usage_event(GatewayDeleteBudgetPolicyEvent)
    def delete_budget_policy(self, budget_policy_id: str) -> None:
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_budget_policy = self._get_entity_or_raise(
                session,
                SqlGatewayBudgetPolicy,
                {"budget_policy_id": budget_policy_id},
                "BudgetPolicy",
            )
            session.delete(sql_budget_policy)

    @record_usage_event(GatewayListBudgetPoliciesEvent)
    def list_budget_policies(
        self,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        page_token: str | None = None,
    ) -> PagedList[GatewayBudgetPolicy]:
        self._validate_max_results_param(max_results)
        offset = SearchUtils.parse_start_offset_from_page_token(page_token)
        with self.ManagedSessionMaker() as session:
            query = (
                self
                ._get_query(session, SqlGatewayBudgetPolicy)
                .order_by(SqlGatewayBudgetPolicy.budget_policy_id)
                .offset(offset)
                .limit(max_results + 1)
            )
            policies = [bp.to_mlflow_entity() for bp in query.all()]
            next_token = None
            if len(policies) > max_results:
                next_token = SearchUtils.create_page_token(offset + max_results)
            return PagedList(policies[:max_results], next_token)

    def sum_gateway_trace_cost(
        self,
        start_time_ms: int,
        end_time_ms: int,
        workspace: str | None = None,
        endpoint_id: str | None = None,
        username: str | None = None,
    ) -> float:
        with self.ManagedSessionMaker() as session:
            query = (
                session
                .query(func.coalesce(func.sum(SqlSpanMetrics.value), 0.0))
                .join(SqlTraceInfo, SqlTraceInfo.request_id == SqlSpanMetrics.trace_id)
                .join(
                    SqlTraceMetadata,
                    SqlTraceMetadata.request_id == SqlTraceInfo.request_id,
                )
                .filter(
                    SqlSpanMetrics.key == SpanMetricKey.TOTAL_COST,
                    SqlTraceMetadata.key == TraceMetadataKey.GATEWAY_ENDPOINT_ID,
                    SqlTraceInfo.timestamp_ms >= start_time_ms,
                    SqlTraceInfo.timestamp_ms < end_time_ms,
                )
            )

            if endpoint_id is not None:
                query = query.filter(SqlTraceMetadata.value == endpoint_id)

            if workspace is not None:
                query = query.join(
                    SqlExperiment,
                    SqlExperiment.experiment_id == SqlTraceInfo.experiment_id,
                ).filter(SqlExperiment.workspace == workspace)

            if username is not None:
                # Filter to traces whose recorded auth username matches the username.
                # Uses a separate aliased join because SqlTraceMetadata is already
                # joined above for the gateway-endpoint marker.
                user_metadata = aliased(SqlTraceMetadata)
                query = query.join(
                    user_metadata,
                    user_metadata.request_id == SqlTraceInfo.request_id,
                ).filter(
                    user_metadata.key == TraceMetadataKey.AUTH_USERNAME,
                    user_metadata.value == username,
                )

            return float(query.scalar())

    # Guardrail APIs

    @record_usage_event(GatewayCreateGuardrailEvent)
    def create_gateway_guardrail(
        self,
        name: str,
        scorer_id: str,
        scorer_version: int,
        stage: GuardrailStage,
        action: GuardrailAction,
        action_endpoint_id: str | None = None,
        created_by: str | None = None,
    ) -> GatewayGuardrail:
        with self.ManagedSessionMaker(read_only=False) as session:
            # Ensure the scorer is valid and in the current workspace
            self._get_scorer_version(session, scorer_id, scorer_version)

            guardrail_id = f"gr-{uuid.uuid4().hex}"
            current_time = get_current_time_millis()

            sql_guardrail = self._with_workspace_field(
                SqlGatewayGuardrail(
                    guardrail_id=guardrail_id,
                    name=name,
                    scorer_id=scorer_id,
                    scorer_version=scorer_version,
                    stage=stage.value,
                    action=action.value,
                    action_endpoint_id=action_endpoint_id,
                    created_at=current_time,
                    last_updated_at=current_time,
                    created_by=created_by,
                    last_updated_by=created_by,
                )
            )

            session.add(sql_guardrail)
            session.flush()

            return sql_guardrail.to_mlflow_entity()

    def get_gateway_guardrail(self, guardrail_id: str) -> GatewayGuardrail:
        with self.ManagedSessionMaker() as session:
            sql_guardrail = self._get_entity_or_raise(
                session,
                SqlGatewayGuardrail,
                {"guardrail_id": guardrail_id},
                "Guardrail",
            )
            return sql_guardrail.to_mlflow_entity()

    @record_usage_event(GatewayDeleteGuardrailEvent)
    def delete_gateway_guardrail(self, guardrail_id: str) -> None:
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_guardrail = self._get_entity_or_raise(
                session,
                SqlGatewayGuardrail,
                {"guardrail_id": guardrail_id},
                "Guardrail",
            )
            session.delete(sql_guardrail)

    def list_gateway_guardrails(
        self,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        page_token: str | None = None,
    ) -> PagedList[GatewayGuardrail]:
        self._validate_max_results_param(max_results)
        offset = SearchUtils.parse_start_offset_from_page_token(page_token)
        with self.ManagedSessionMaker() as session:
            query = (
                self
                ._get_query(session, SqlGatewayGuardrail)
                .order_by(SqlGatewayGuardrail.guardrail_id)
                .offset(offset)
                .limit(max_results + 1)
            )
            guardrails = [g.to_mlflow_entity() for g in query.all()]
            next_token = None
            if len(guardrails) > max_results:
                next_token = SearchUtils.create_page_token(offset + max_results)
            return PagedList(guardrails[:max_results], next_token)

    def add_guardrail_to_endpoint(
        self,
        endpoint_id: str,
        guardrail_id: str,
        execution_order: int | None = None,
        created_by: str | None = None,
    ) -> GatewayGuardrailConfig:
        with self.ManagedSessionMaker(read_only=False) as session:
            # Validate both endpoint and guardrail exist
            self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "Endpoint"
            )
            self._get_entity_or_raise(
                session, SqlGatewayGuardrail, {"guardrail_id": guardrail_id}, "Guardrail"
            )

            sql_config = self._with_workspace_field(
                SqlGatewayGuardrailConfig(
                    endpoint_id=endpoint_id,
                    guardrail_id=guardrail_id,
                    execution_order=execution_order,
                    created_by=created_by,
                    created_at=get_current_time_millis(),
                )
            )

            try:
                session.add(sql_config)
                session.flush()
            except IntegrityError as e:
                raise MlflowException(
                    f"Guardrail '{guardrail_id}' is already added to endpoint '{endpoint_id}'",
                    error_code=RESOURCE_ALREADY_EXISTS,
                ) from e

            return sql_config.to_mlflow_entity()

    @record_usage_event(GatewayUpdateGuardrailEvent)
    def update_endpoint_guardrail_config(
        self,
        endpoint_id: str,
        guardrail_id: str,
        execution_order: int | None = None,
    ) -> GatewayGuardrailConfig:
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_config = self._get_entity_or_raise(
                session,
                SqlGatewayGuardrailConfig,
                {"endpoint_id": endpoint_id, "guardrail_id": guardrail_id},
                "GuardrailConfig",
            )
            sql_config.execution_order = execution_order
            session.flush()
            return sql_config.to_mlflow_entity()

    def remove_guardrail_from_endpoint(
        self,
        endpoint_id: str,
        guardrail_id: str,
    ) -> None:
        with self.ManagedSessionMaker(read_only=False) as session:
            sql_config = self._get_entity_or_raise(
                session,
                SqlGatewayGuardrailConfig,
                {"endpoint_id": endpoint_id, "guardrail_id": guardrail_id},
                "GuardrailConfig",
            )
            session.delete(sql_config)

    def list_endpoint_guardrail_configs(
        self,
        endpoint_id: str,
    ) -> list[GatewayGuardrailConfig]:
        with self.ManagedSessionMaker() as session:
            self._get_entity_or_raise(
                session, SqlGatewayEndpoint, {"endpoint_id": endpoint_id}, "Endpoint"
            )
            configs = (
                self
                ._get_query(session, SqlGatewayGuardrailConfig)
                .options(joinedload(SqlGatewayGuardrailConfig.guardrail))
                .filter(SqlGatewayGuardrailConfig.endpoint_id == endpoint_id)
                .order_by(
                    case((SqlGatewayGuardrailConfig.execution_order.is_(None), 1), else_=0).asc(),
                    SqlGatewayGuardrailConfig.execution_order.asc(),
                    SqlGatewayGuardrailConfig.guardrail_id,
                )
                .all()
            )
            return [c.to_mlflow_entity() for c in configs]
