from dataclasses import asdict, dataclass, field
from typing import Any

from mlflow.entities.gateway_endpoint import (
    FallbackConfig,
    FallbackStrategy,
    GatewayModelLinkageType,
    RoutingStrategy,
)


@dataclass
class GatewayModelConfig:
    """
    Model configuration with decrypted credentials for runtime use.

    This entity contains everything needed to make LLM API calls, including
    the decrypted secrets and auth configuration. This is only used
    server-side and should never be exposed to clients.

    Args:
        model_definition_id: Unique identifier for the model definition.
        provider: LLM provider (e.g., "openai", "anthropic", "cohere", "bedrock").
        model_name: Provider-specific model identifier (e.g., "gpt-4o").
        secret_value: Decrypted secrets as a dict. For providers with multiple
            auth modes, contains all secret fields (e.g., {"aws_access_key_id": "...",
            "aws_secret_access_key": "..."}). For simple providers, contains
            {"api_key": "..."}.
        auth_config: Non-secret configuration including auth_mode (e.g.,
            {"auth_mode": "access_keys", "aws_region_name": "us-east-1"}).
        weight: Routing weight for traffic distribution (default 1.0).
        linkage_type: Type of linkage (PRIMARY or FALLBACK).
        fallback_order: Order for fallback attempts (only for FALLBACK linkages, None for PRIMARY).
    """

    model_definition_id: str
    provider: str
    model_name: str
    secret_value: dict[str, Any]
    auth_config: dict[str, Any] | None = None
    weight: float = 1.0
    linkage_type: GatewayModelLinkageType = GatewayModelLinkageType.PRIMARY
    fallback_order: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GatewayModelConfig":
        data = {**data}
        data["linkage_type"] = GatewayModelLinkageType(data["linkage_type"])
        return cls(**data)


@dataclass
class GatewayEndpointConfig:
    """
    Complete endpoint configuration for resource runtime use.

    This entity contains all information needed for a resource to make LLM API calls,
    including decrypted secrets and routing configuration. This is only used server-side
    and should never be exposed to clients.

    Args:
        endpoint_id: Unique identifier for the endpoint.
        endpoint_name: User-friendly name for the endpoint.
        models: List of model configurations with decrypted credentials.
        routing_strategy: Optional routing strategy (e.g., FALLBACK).
        fallback_config: Optional fallback configuration from GatewayEndpoint entity.
        experiment_id: Optional experiment ID for tracing (if usage tracking is enabled).
    """

    endpoint_id: str
    endpoint_name: str
    models: list[GatewayModelConfig] = field(default_factory=list)
    routing_strategy: RoutingStrategy | None = None
    fallback_config: FallbackConfig | None = None
    experiment_id: str | None = None
    usage_tracking: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GatewayEndpointConfig":
        data = {**data}
        models = [GatewayModelConfig.from_dict(m) for m in data.pop("models", [])]
        fc_data = data.pop("fallback_config", None)
        if fc_data:
            fc_data = {**fc_data}
            if fc_data.get("strategy"):
                fc_data["strategy"] = FallbackStrategy(fc_data["strategy"])
        fallback = FallbackConfig(**fc_data) if fc_data else None
        if data.get("routing_strategy"):
            data["routing_strategy"] = RoutingStrategy(data["routing_strategy"])
        return cls(**data, models=models, fallback_config=fallback)
